class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def insert_at_end(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            return
        last = self.head
        while last.next:
            last = last.next
        last.next = new_node

    def display(self):
        current = self.head
        while current:
            print(current.data, end=" -> ")
            current = current.next
        print("None")

    def remove_beginning(self):
        if self.head:
            removed_data = self.head.data
            self.head = self.head.next
            return removed_data
        else:
            print("None. Cannot remove from an empty list.")
            return None

    def remove_end(self):
        if not self.head:
            print("None. Cannot remove from an empty list.")
            return None
        if not self.head.next:
            removed_data = self.head.data
            self.head = None
            return removed_data
        second_last = self.head
        while second_last.next.next:
            second_last = second_last.next
        removed_data = second_last.next.data
        second_last.next = None
        return removed_data

    def remove_at(self, position):
        if position < 0:
            print("Invalid position. Cannot remove.")
            return None
        if not self.head:
            print("None. Cannot remove from an empty list.")
            return None
        if position == 0:
            removed_data = self.head.data
            self.head = self.head.next
            return removed_data

        current = self.head
        prev = None
        count = 0
        while current and count < position:
            prev = current
            current = current.next
            count += 1
        if not current:
            print("Position out of bounds. Cannot remove.")
            return None
        removed_data = current.data
        prev.next = current.next
        return removed_data

# Example usage
burger = LinkedList()
burger.insert_at_end("Bottom Bun")
burger.insert_at_end("Meat and Vegetables")
burger.insert_at_end("Top Bun")

print("Initial burger:")
burger.display()

print("\nRemoved at beginning:", burger.remove_beginning())
burger.display()

print("\nRemoved at end:", burger.remove_end())
burger.display()

print("\nRemoved at position 5:", burger.remove_at(5))
burger.display()
