from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/works', methods=['GET', 'POST'])
def works():
    return render_template('works.html')

@app.route('/areacircle', methods=['GET', 'POST'])
def areacircle():
    area = None  
    if request.method == 'POST':
        try:
            radius = float(request.form.get('radius', ''))  
            area = 3.14159 * (radius ** 2)  
        except ValueError:
            area = "Invalid input. Please enter a number." 
    return render_template('areacircle.html', area=area)

@app.route('/areatriangle', methods=['GET', 'POST'])
def areatriangle():
    area = None
    if request.method == 'POST':
        try:
            base = float(request.form.get('base', ''))
            height = float(request.form.get('height', ''))
            area = 0.5 * base * height
        except ValueError:
            area = "Invalid input. Please enter numbers for base and height."
    return render_template('areatriangle.html', area=area)

@app.route('/touppercase', methods=['GET', 'POST'])
def touppercase():
    result = None
    if request.method == 'POST':
        input_string = request.form.get('inputString', '')
        result = input_string.upper()
    return render_template('touppercase.html', result=result)

@app.route('/linkedlist', methods=['GET', 'POST'])
def burgerlinkedlist():
    class Node:
        def __init__(self, data):
            self.data = data
            self.next = None

    class LinkedList:
        def __init__(self):
            self.head = None

        def insert_at_end(self, data):
            new_node = Node(data)
            if not self.head:
                self.head = new_node
                return
            last = self.head
            while last.next:
                last = last.next
            last.next = new_node

        def display(self):
            elements = []
            current = self.head
            while current:
                elements.append(current.data)
                current = current.next
            return elements

        def remove_beginning(self):
            if not self.head:
                return None
            removed_data = self.head.data
            self.head = self.head.next
            return removed_data

        def remove_end(self):
            if not self.head:
                return None
            if not self.head.next:
                removed_data = self.head.data
                self.head = None
                return removed_data
            second_last = self.head
            while second_last.next.next:
                second_last = second_last.next
            removed_data = second_last.next.data
            second_last.next = None
            return removed_data

        def remove_at(self, position):
            if position < 0 or not self.head:
                return None
            if position == 0:
                removed_data = self.head.data
                self.head = self.head.next
                return removed_data

            current = self.head
            prev = None
            count = 0
            while current and count < position:
                prev = current
                current = current.next
                count += 1
            if not current:
                return None
            removed_data = current.data
            prev.next = current.next
            return removed_data

    burger = LinkedList()
    burger.insert_at_end("Bottom Bun")
    burger.insert_at_end("Meat and Vegetables")
    burger.insert_at_end("Top Bun")

    print("Initial burger:", burger.display())
    print("Removed beginning:", burger.remove_beginning())
    print("After removing beginning:", burger.display())
    print("Removed end:", burger.remove_end())
    print("After removing end:", burger.display())
    print("Removed at position 1:", burger.remove_at(1))
    print("After removing at position 1:", burger.display())

    return render_template('linkedlist.html', burger=burger.display())


@app.route('/contact')
def contact():
    return render_template('contact.html')

if __name__ == "__main__":
    app.run(debug=True)
